import { View } from "react-native"

const WorkCompletedBody = ({workList, reload, navigation}) => {
    return(
        <View>
            
        </View>
    )
}