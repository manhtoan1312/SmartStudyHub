const DeletedAvatarList = () => {
    const fetchData = async =() => {

    }
}

export default DeletedAvatarList