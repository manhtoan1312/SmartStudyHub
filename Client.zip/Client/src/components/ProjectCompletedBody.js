const ProjectCompletedBody =({projectList, reload, navigation}) => {
    return(
        <View>
            
        </View>
    )
}