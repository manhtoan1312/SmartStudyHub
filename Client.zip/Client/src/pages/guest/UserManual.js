export default function UserManual({}) {

}